import { Component } from '@angular/core';

@Component({
  selector: 'app-crypto-detail',
  imports: [],
  templateUrl: './crypto-detail.component.html',
  styleUrl: './crypto-detail.component.css'
})
export class CryptoDetailComponent {

}
