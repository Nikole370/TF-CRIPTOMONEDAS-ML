import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-investment-simulation',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './investment-simulation.component.html',
  styleUrls: ['./investment-simulation.component.css']
})
export class InvestmentSimulationComponent {

}
