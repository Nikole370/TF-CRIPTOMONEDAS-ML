import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-model-info',
  imports: [CommonModule],
  templateUrl: './model-info.component.html',
  styleUrl: './model-info.component.css'
})
export class ModelInfoComponent {

}
